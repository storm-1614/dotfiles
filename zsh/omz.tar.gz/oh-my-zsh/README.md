### zshrc在`templates/zshrc.zsh-template`内，请复制到`~/.zshrc`。    
默认主题是pure,omz内置主题没有删  
